Folders and details
1. "Multiplier" contain VHDL code of 8*8 array multiplier design.
2. "JTAG design" contain all the JTAG components and their testbenches. For running the top module in this folder, the BSR should be mapped with the testing design.
3. "JTAG with multipiler". This folder is the integration of JTAG with the multiplier. The top modules works fine. I have attached top module's test bench in different folder ["Testbench_for_top_module"]